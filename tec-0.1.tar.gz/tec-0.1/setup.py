from setuptools import setup, find_packages

setup(name='tec',
	version='0.1',
	packages=find_packages(),
	description='Proyecto 2 - Inteligencia Artificial',
	url='https://github.com/MarAvFe/ia-p2/',
	author='Grupo 04 IA: Marcelo Ávila, Stefi Falcón, Nelson Gómez',
	package_data={
	'tec.ic.ia.p2': ['*'],
	'tec.ic.ia.p2.imagenesReadme': ['*'],
	'tec.ic.ia.p2.etymwn': ['*']
	},
    classifiers=[],
	)
